GLOBALPEDIA LIVE NEWS PATCH

This patch connects the existing /api/news backend to the homepage.

It adds:
- Latest News section
- World / Pakistan / Technology / Science live stories
- Immediate fetch on page load
- Automatic refresh every 10 minutes while the browser page is open
- Manual refresh button
- Updated time indicator
- Loading skeletons
- Error state
- LIVE badge and animations
- News navigation link

Run from:
C:\Users\FALCON SOLUTION\Downloads\faaaah

Command:
powershell -ExecutionPolicy Bypass -File .\add-live-news.ps1

Then:
npm run build
git add .
git commit -m "feat: wire live news to homepage"
git push origin main

Note: Vercel Hobby Cron is not required for this browser-polling approach.
